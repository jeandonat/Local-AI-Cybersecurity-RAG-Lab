# JD Master Persona

Uses:
- Llama 3.1 (13B) for reasoning
- Qwen 2.5 (14B) for deep technical responses

Integrated into native Ollama with OpenWebUI.
