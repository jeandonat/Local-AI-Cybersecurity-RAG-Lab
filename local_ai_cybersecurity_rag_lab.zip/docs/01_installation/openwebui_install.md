# OpenWebUI Installation

Installed via:

```
pip install open-webui
open-webui serve
```

Then connected to native Ollama:

```
http://localhost:11434
```
