# Native Ollama Installation

Install:

```
curl https://ollama.ai/install.sh | sh
```

Check:

```
ollama --version
```

Models stored in `~/.ollama/models`.
