# Model Installation

## Llama 3.1 (13B)
```
ollama pull llama3.1:13b
```

## Ollama 13B (Llama 3 family)
```
ollama pull llama3:13b
```

## Qwen 2.5 (14B)
```
ollama pull qwen2.5:14b
```

Check installed:
```
ollama list
```
