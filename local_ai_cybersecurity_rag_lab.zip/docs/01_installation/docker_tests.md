# Docker-based Ollama (Used During Testing)

Used temporarily for verification.

Commands:

```
docker pull ollama/ollama:latest
docker run -p 11434:11434 ollama/ollama
```

This was later removed in favor of the **native installation**.
