# RAG Setup

Built using OpenWebUI's knowledge base.

Sources:
- Wikipedia dump
- MITRE ATT&CK dataset

Steps:
1. Place files inside: `rag/datasets/`
2. Use ingestion scripts
3. OpenWebUI → Knowledge → Import
