# MITRE ATT&CK Integration

MITRE ATT&CK json dataset can be ingested into vector DB.

Use Qwen for technical queries and Llama3 for reasoning.
