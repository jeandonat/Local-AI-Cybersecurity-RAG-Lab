#!/bin/bash
echo 'Ingesting Wikipedia dump...'
