# Local AI Cybersecurity RAG Lab

This project documents a complete **native + Docker hybrid AI environment** using:
- **Ollama (Native installation)**
- **Ollama (Docker variant used during testing)**
- **Models:**
  - **Llama 3.1 (13B)**
  - **Ollama 13B** (Llama3 family)
  - **Qwen 2.5 (14B)**
- **OpenWebUI** connected to native Ollama
- **JD Master Persona**
- **Wikipedia + MITRE ATT&CK RAG system**

Everything runs fully local on RTX 3060.
